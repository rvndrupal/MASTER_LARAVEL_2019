<?php /* /Users/iparra/cursos/prod/laravel-timezones-cron/resources/views/tweets/index.blade.php */ ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header">Listado de tweets</div>

                    <div class="card-body">
                        <a href="<?php echo e(route('tweets.form')); ?>" class="btn btn-info text-white float-right">Añadir Tweet</a>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Tweet</th>
                                    <th scope="col">Publicar en fecha</th>
                                    <th scope="col">Fecha según TZ</th>
                                    <th scope="col">Zona horaria</th>
                                    <th scope="col">Publicado</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $tweets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tweet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <th><?php echo e($tweet->id); ?></th>
                                    <td><?php echo e($tweet->tweet); ?></td>
                                    <td><?php echo e($tweet->published_at->format('d/m/Y H:i:s')); ?></td>
                                    <td><?php echo e($tweet->original_datetime->format('d/m/Y H:i:s')); ?></td>
                                    <td><?php echo e($tweet->timezone); ?></td>
                                    <td><?php echo e($tweet->published); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5">no nay tweets</td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>