<?php /* /Users/iparra/cursos/prod/laravel-timezones-cron/resources/views/tweets/form.blade.php */ ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Formulario de tweets</div>

                    <div class="card-body">
                        <form action="<?php echo e(route('tweets.publish')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="datetime">Fecha</label>
                                <input type="datetime-local" name="datetime" class="form-control" id="datetime">
                            </div>
                            <div class="form-group">
                                <label for="timezones">Selecciona la zona horaria</label>
                                <select class="form-control" id="timezones" name="timezone">
                                    <?php $__currentLoopData = DateTimeZone::listIdentifiers(DateTimeZone::ALL); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timezone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($timezone); ?>"><?php echo e($timezone); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="tweet">Tweet</label>
                                <textarea name="tweet" class="form-control" id="tweet" rows="3"></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary mb-2">Programar Tweet</button>
                            <a href="<?php echo e(route('tweets.list')); ?>" class="btn btn-info text-white mb-2">Listado de Tweets</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>